# Ross Cameron-Style Momentum AI Proxy (Upload Pack)
Version: 1.0
Created: 2025-10-12

This pack provides **stats, rules, and configuration** to bootstrap a small-cap momentum
"Ross Cameron / Warrior-style" *proxy* strategy for your AI assistant (Claude, etc.).
It does **not** contain proprietary Warrior Trading parameters; it's a best-effort public proxy
based on commonly described elements of the style.

## Contents
- `config/ross_proxy_strategy.yaml`: Tunable thresholds and weights.
- `config/risk_profile.yaml`: Risk and trailing stop policy.
- `data/templates/feature_schema.json`: Features the AI should compute per candidate signal.
- `data/templates/dataset_schema.csv`: Columns your historical dataset should include.
- `data/templates/backtest_metrics_template.csv`: Where to accumulate validation metrics.
- `rules/ruleset.json`: Hard "gating" rules to cut false positives.
- `pipeline/labeling_spec.md`: How to label targets (TP-before-SL).
- `pipeline/training_plan.md`: Model training, calibration, walk-forward.
- `pipeline/inference_policy.md`: Live decision policy (score → entry/size/exit).
- `prompts/claude_profile_prompt.txt`: Copy/paste prompt for Claude to ingest this pack.
- `LICENSE.txt`: Usage terms (MIT).

## Quick Start
1. Load `prompts/claude_profile_prompt.txt` into Claude and upload this zip.
2. Point Claude to `config/ross_proxy_strategy.yaml` and `rules/ruleset.json` for core logic.
3. Map your historical candles/volume/float data to `data/templates/dataset_schema.csv` headers.
4. Ask Claude to: (a) generate features per `feature_schema.json`, (b) label per `labeling_spec.md`,
   (c) train per `training_plan.md`, and (d) simulate inference per `inference_policy.md`.
5. Tune thresholds using the backtest metrics.

## Disclaimer
This is **educational** and for research/backtesting only. Markets carry risk.
No performance guarantee is implied.
