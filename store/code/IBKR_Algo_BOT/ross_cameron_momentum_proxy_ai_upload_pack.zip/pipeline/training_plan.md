# Training Plan
- Build features per schema; create candidate signals from ruleset gates.
- Walk-forward split by date; tune gradient boosting/logistic.
- Class weights or focal loss for imbalance.
- Calibrate probabilities (isotonic).
- Evaluate: WinRate, Expectancy (R), Profit Factor, Brier, PR-AUC, ROC-AUC.
- Sensitivity: p_min in [0.55, 0.70]; ATR TP/SL multiples grid.
- Segment by regime (vol, trend); re-calibrate per regime.