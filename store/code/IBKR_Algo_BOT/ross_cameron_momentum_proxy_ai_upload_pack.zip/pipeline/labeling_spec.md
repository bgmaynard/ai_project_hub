# Labeling Spec: TP-before-SL Target
H = config.scoring.horizon_bars
TP = entry + target_take_profit_atr * ATR(entry_time)
SL = entry - target_stop_loss_atr * ATR(entry_time)
Label 1 if TP is hit before SL within H bars; else 0.
Use intrabar highs/lows; include slippage model. Mirror for shorts.