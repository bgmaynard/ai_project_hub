# Inference Policy
1) Apply gates (ruleset.json). If pass → compute features.
2) Score PPS = Prob(TP before SL). If PPS ≥ p_min → proceed.
3) Size = (risk_per_trade_pct_equity * equity) / stop_distance.
4) Trailing per risk_profile.yaml (chandelier/atr_step/vwap_assist/momentum).
5) Exit if stop, PPS < exit_threshold, MACD hist failure, or VWAP breakdown.
6) Log MFE/MAE, slippage; update rolling calibration and setup stats.